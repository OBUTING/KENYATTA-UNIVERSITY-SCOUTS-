const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies
app.use(express.json());

// Serve static files (your HTML, CSS, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// File to store messages
const MESSAGES_FILE = 'messages.json';

// Initialize messages file if it doesn't exist
async function initializeMessagesFile() {
    try {
        await fs.access(MESSAGES_FILE);
    } catch {
        await fs.writeFile(MESSAGES_FILE, JSON.stringify([]));
    }
}

// Endpoint to receive messages
app.post('/send-message', async (req, res) => {
    try {
        const { name, email, message, date } = req.body;

        // Basic validation
        if (!name || !email || !message) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        // Read existing messages
        const messagesData = await fs.readFile(MESSAGES_FILE, 'utf8');
        const messages = JSON.parse(messagesData);

        // Add new message
        messages.push({
            name,
            email,
            message,
            date,
            id: Date.now() // Simple unique ID
        });

        // Save updated messages
        await fs.writeFile(MESSAGES_FILE, JSON.stringify(messages, null, 2));

        res.status(200).json({ message: 'Message received successfully' });
    } catch (error) {
        console.error('Error processing message:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Endpoint to view messages (optional, for admin use)
app.get('/messages', async (req, res) => {
    try {
        const messagesData = await fs.readFile(MESSAGES_FILE, 'utf8');
        res.json(JSON.parse(messagesData));
    } catch (error) {
        res.status(500).json({ error: 'Error reading messages' });
    }
});

// Start server
async function startServer() {
    await initializeMessagesFile();
    app.listen(PORT, () => {
        console.log(`Server running on http://localhost:${PORT}`);
    });
}

startServer();